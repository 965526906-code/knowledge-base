from pathlib import Path
import sys

TARGETS = [
    Path('/home/ubuntu/urinary_stone_src_1/output/blue_qr_square_new_url.png'),
    Path('/home/ubuntu/urinary_stone_src_1/output/blue_qr_poster_new_url.png'),
]

try:
    import cv2
except Exception as e:
    print(f'IMPORT_ERROR: {e}')
    sys.exit(2)

detector = cv2.QRCodeDetector()
for path in TARGETS:
    img = cv2.imread(str(path))
    if img is None:
        print(f'FAILED_READ {path}')
        continue
    data, points, _ = detector.detectAndDecode(img)
    if data:
        print(f'OK {path} -> {data}')
    else:
        print(f'NO_DECODE {path}')
