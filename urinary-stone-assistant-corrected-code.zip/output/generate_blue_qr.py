from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import qrcode
from qrcode.constants import ERROR_CORRECT_H

BASE_DIR = Path('/home/ubuntu/urinary_stone_src_1/output')
URL = 'https://3001-i9dp2jjyt8rfho4j81yah-25b2f612.sg1.manus.computer/knowledge'
LOGO_PATH = BASE_DIR / 'hospital_logo.png'
OUT_PATH = BASE_DIR / 'blue_qr_poster_new_url.png'
SQUARE_OUT_PATH = BASE_DIR / 'blue_qr_square_new_url.png'
FONT_PATH = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
FONT_BOLD_PATH = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'

DARK_BLUE = '#1565C0'
MID_BLUE = '#1E88E5'
LIGHT_BLUE = '#EAF4FF'
TEXT_DARK = '#1F2937'
TEXT_MUTED = '#6B7280'
WHITE = '#FFFFFF'


def rounded_rect_mask(size, radius):
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size[0] - 1, size[1] - 1), radius=radius, fill=255)
    return mask


def paste_center(base, overlay, center_xy, mask=None):
    x = int(center_xy[0] - overlay.size[0] / 2)
    y = int(center_xy[1] - overlay.size[1] / 2)
    base.paste(overlay, (x, y), mask if mask is not None else overlay)


def fit_text(draw, text, font_path, max_width, start_size):
    size = start_size
    while size >= 18:
        font = ImageFont.truetype(font_path, size)
        bbox = draw.textbbox((0, 0), text, font=font)
        if bbox[2] - bbox[0] <= max_width:
            return font
        size -= 2
    return ImageFont.truetype(font_path, 18)


qr = qrcode.QRCode(
    version=None,
    error_correction=ERROR_CORRECT_H,
    box_size=18,
    border=4,
)
qr.add_data(URL)
qr.make(fit=True)
qr_img = qr.make_image(fill_color=DARK_BLUE, back_color=WHITE).convert('RGBA')
qr_size = qr_img.size[0]

logo = Image.open(LOGO_PATH).convert('RGBA')
logo_side = int(qr_size * 0.16)
logo.thumbnail((logo_side, logo_side), Image.LANCZOS)

logo_bg_side = int(logo_side * 1.25)
logo_bg = Image.new('RGBA', (logo_bg_side, logo_bg_side), (255, 255, 255, 0))
mask = rounded_rect_mask((logo_bg_side, logo_bg_side), radius=logo_bg_side // 2)
white_disc = Image.new('RGBA', (logo_bg_side, logo_bg_side), WHITE)
logo_bg.paste(white_disc, (0, 0), mask)
paste_center(logo_bg, logo, (logo_bg_side / 2, logo_bg_side / 2), logo)

qr_with_logo = qr_img.copy()
paste_center(qr_with_logo, logo_bg, (qr_size / 2, qr_size / 2), logo_bg)
qr_with_logo.save(SQUARE_OUT_PATH)

canvas_w, canvas_h = 1600, 2180
canvas = Image.new('RGBA', (canvas_w, canvas_h), WHITE)
draw = ImageDraw.Draw(canvas)

# soft blue header band
header = Image.new('RGBA', (canvas_w, 320), LIGHT_BLUE)
canvas.paste(header, (0, 0))

# top circular logo
header_logo = ImageOps.contain(logo.copy(), (180, 180))
header_bg = Image.new('RGBA', (220, 220), (255, 255, 255, 0))
header_mask = rounded_rect_mask((220, 220), radius=110)
header_disc = Image.new('RGBA', (220, 220), WHITE)
header_bg.paste(header_disc, (0, 0), header_mask)
paste_center(header_bg, header_logo, (110, 110), header_logo)
paste_center(canvas, header_bg, (250, 160), header_bg)

hospital_font = fit_text(draw, '广州医科大学附属第一医院', FONT_BOLD_PATH, 980, 64)
dept_font = fit_text(draw, '泌尿外科', FONT_BOLD_PATH, 600, 54)
title_font = fit_text(draw, '泌尿系感染性结石随访管理循证智能助手', FONT_BOLD_PATH, 1320, 70)
sub_font = ImageFont.truetype(FONT_PATH, 34)
caption_font = ImageFont.truetype(FONT_BOLD_PATH, 38)
small_font = ImageFont.truetype(FONT_PATH, 26)

text_x = 430
draw.text((text_x, 90), '广州医科大学附属第一医院', font=hospital_font, fill=DARK_BLUE)
draw.text((text_x, 175), '泌尿外科', font=dept_font, fill=MID_BLUE)
draw.rounded_rectangle((text_x, 245, text_x + 240, 254), radius=5, fill='#F59E0B')

# main title
bbox = draw.textbbox((0, 0), '泌尿系感染性结石随访管理循证智能助手', font=title_font)
title_w = bbox[2] - bbox[0]
draw.text(((canvas_w - title_w) / 2, 390), '泌尿系感染性结石随访管理循证智能助手', font=title_font, fill=TEXT_DARK)

sub = '扫码进入新发布的系统入口'
bbox = draw.textbbox((0, 0), sub, font=sub_font)
draw.text(((canvas_w - (bbox[2]-bbox[0])) / 2, 500), sub, font=sub_font, fill=TEXT_MUTED)

# QR card
card_x1, card_y1 = 105, 610
card_x2, card_y2 = canvas_w - 105, 1700
shadow = Image.new('RGBA', (card_x2 - card_x1 + 16, card_y2 - card_y1 + 16), (0, 0, 0, 0))
shadow_draw = ImageDraw.Draw(shadow)
shadow_draw.rounded_rectangle((8, 8, shadow.size[0]-1, shadow.size[1]-1), radius=40, fill=(21, 101, 192, 28))
canvas.alpha_composite(shadow, (card_x1 - 8, card_y1 - 4))
card = Image.new('RGBA', (card_x2 - card_x1, card_y2 - card_y1), WHITE)
card_draw = ImageDraw.Draw(card)
card_draw.rounded_rectangle((0, 0, card.size[0]-1, card.size[1]-1), radius=40, fill=WHITE, outline='#D7E8FF', width=4)
canvas.alpha_composite(card, (card_x1, card_y1))

qr_target_side = 1120
qr_resized = qr_with_logo.resize((qr_target_side, qr_target_side), Image.LANCZOS)
paste_center(canvas, qr_resized, (canvas_w / 2, 1180), qr_resized)

# label under QR
label = '广州医科大学附属第一医院泌尿外科'
label_font = fit_text(draw, label, FONT_BOLD_PATH, 1250, 44)
bbox = draw.textbbox((0, 0), label, font=label_font)
label_w = bbox[2] - bbox[0]
draw.text(((canvas_w - label_w) / 2, 1790), label, font=label_font, fill=DARK_BLUE)

caption = '请使用微信或手机相机扫描'
bbox = draw.textbbox((0, 0), caption, font=caption_font)
draw.text(((canvas_w - (bbox[2]-bbox[0])) / 2, 1870), caption, font=caption_font, fill=MID_BLUE)

url_text = URL
bbox = draw.textbbox((0, 0), url_text, font=small_font)
draw.text(((canvas_w - (bbox[2]-bbox[0])) / 2, 1936), url_text, font=small_font, fill=TEXT_MUTED)

note = '二维码中心已嵌入单位标识'
bbox = draw.textbbox((0, 0), note, font=small_font)
draw.text(((canvas_w - (bbox[2]-bbox[0])) / 2, 1990), note, font=small_font, fill=TEXT_MUTED)

canvas.save(OUT_PATH)
print(OUT_PATH)
print(SQUARE_OUT_PATH)
