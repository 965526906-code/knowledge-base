/*
 * Design: Warm Guardian - 底部常驻随访登记入口
 * 固定在底部，方便护士快速进入随访登记
 */
import { Link } from "wouter";
import { ClipboardList } from "lucide-react";

export default function BottomBar() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-[0_-4px_12px_rgba(0,0,0,0.08)]">
      <div className="max-w-lg mx-auto px-4 py-2">
        <Link href="/registration">
          <button className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-[#F57C00] to-[#FF8F00] text-white rounded-xl font-semibold text-base shadow-md hover:shadow-lg transition-all active:scale-[0.98]">
            <ClipboardList className="w-5 h-5" />
            <span>随访登记系统</span>
          </button>
        </Link>
      </div>
    </div>
  );
}
