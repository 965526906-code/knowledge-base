/*
 * Design: Warm Guardian - 人文关怀医疗设计
 * Header: 白色背景导航栏，浅灰底部分割线，Logo清晰可见
 */
import { Link, useLocation } from "wouter";
import { ArrowLeft, Home } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663379302955/mmDvxYoGwM495rh6KFrCar/泌外医学中心_fc9a872d.png";

export default function Header() {
  const [location] = useLocation();
  const isHome = location === "/";

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
        {!isHome && (
          <Link href="/">
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors">
              <ArrowLeft className="w-5 h-5 text-[#1565C0]" />
            </button>
          </Link>
        )}
        <img
          src={LOGO_URL}
          alt="泌外医学中心"
          className="w-10 h-10 rounded-full border-2 border-[#1565C0]/20 flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-500 tracking-wide">广州医科大学附属第一医院</p>
          <p className="text-sm font-semibold text-[#1565C0] tracking-wider">泌尿外科</p>
        </div>
        {!isHome && (
          <Link href="/">
            <button className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors">
              <Home className="w-5 h-5 text-[#1565C0]" />
            </button>
          </Link>
        )}
      </div>
    </header>
  );
}
