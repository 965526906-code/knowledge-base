/*
 * Design: Warm Guardian - 随访评估模块
 * 功能：症状自测、复查指标对比、风险分级评估
 * 纯白背景，无背景图
 */
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Activity, AlertTriangle, CheckCircle2, ChevronDown, ChevronUp, Info } from "lucide-react";
import Header from "@/components/Header";
import BottomBar from "@/components/BottomBar";
import { Button } from "@/components/ui/button";

interface SymptomItem {
  id: string;
  label: string;
  description: string;
  riskWeight: number;
}

const symptoms: SymptomItem[] = [
  { id: "fever", label: "发热（体温≥37.5°C）", description: "术后发热可能提示感染", riskWeight: 3 },
  { id: "pain", label: "腰部或腹部疼痛", description: "持续性疼痛需警惕结石复发或梗阻", riskWeight: 2 },
  { id: "hematuria", label: "血尿", description: "肉眼血尿或镜下血尿", riskWeight: 2 },
  { id: "dysuria", label: "尿频、尿急、尿痛", description: "可能提示尿路感染", riskWeight: 2 },
  { id: "nausea", label: "恶心或呕吐", description: "可能与肾绞痛或感染相关", riskWeight: 1 },
  { id: "turbid", label: "尿液浑浊或有异味", description: "可能提示尿路感染", riskWeight: 2 },
  { id: "oliguria", label: "尿量减少", description: "可能提示梗阻或肾功能异常", riskWeight: 3 },
  { id: "stent", label: "输尿管支架管不适", description: "支架管留置相关症状", riskWeight: 1 },
];

const labItems = [
  { name: "尿常规（白细胞酯酶）", normal: "阴性", unit: "", key: "wbc" },
  { name: "尿常规（亚硝酸盐）", normal: "阴性", unit: "", key: "nitrite" },
  { name: "尿pH值", normal: "6.0-6.5", unit: "", key: "ph" },
  { name: "血肌酐", normal: "44-133", unit: "μmol/L", key: "creatinine" },
  { name: "eGFR", normal: "≥60", unit: "mL/min/1.73m²", key: "egfr" },
  { name: "血尿酸", normal: "150-420", unit: "μmol/L", key: "uricacid" },
  { name: "24h尿量", normal: "≥2000", unit: "mL", key: "urine24h" },
];

type RiskLevel = "low" | "medium" | "high" | null;

export default function FollowupAssessment() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<Set<string>>(new Set());
  const [showResult, setShowResult] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>("symptoms");

  const toggleSymptom = (id: string) => {
    const next = new Set(selectedSymptoms);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedSymptoms(next);
  };

  const calculateRisk = (): RiskLevel => {
    let totalWeight = 0;
    selectedSymptoms.forEach((id) => {
      const s = symptoms.find((x) => x.id === id);
      if (s) totalWeight += s.riskWeight;
    });
    if (totalWeight === 0) return "low";
    if (totalWeight <= 3) return "medium";
    return "high";
  };

  const risk = showResult ? calculateRisk() : null;

  const riskConfig = {
    low: { label: "低风险", color: "text-green-700", bg: "bg-green-50", border: "border-green-200", icon: CheckCircle2, advice: "目前症状评估为低风险。建议按常规随访计划进行复查：治疗后1周、1个月、3个月各随访1次，之后每3个月随访1次。" },
    medium: { label: "中风险", color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200", icon: Info, advice: "存在部分症状需要关注。建议缩短随访间隔，尽快完成尿常规、尿培养等检查，并联系主治医生评估是否需要调整治疗方案。" },
    high: { label: "高风险", color: "text-red-700", bg: "bg-red-50", border: "border-red-200", icon: AlertTriangle, advice: "存在较多或较严重的症状，建议立即就医！可能需要进行紧急影像学检查（超声/CT）和实验室检查，排除感染加重、梗阻或结石复发。" },
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Page Title - 纯白背景，无背景图 */}
      <div className="bg-white px-4 pt-6 pb-4 max-w-lg mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center">
            <Activity className="w-6 h-6 text-[#1565C0]" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">随访评估</h1>
            <p className="text-sm text-gray-500">症状自测 · 指标对比 · 风险分级</p>
          </div>
        </div>
        <div className="mt-3 h-[1px] bg-gray-100" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-2 pb-28 w-full space-y-4 bg-white">
        {/* Symptom Self-Test */}
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          <button
            onClick={() => toggleSection("symptoms")}
            className="w-full flex items-center justify-between p-4 text-left"
          >
            <div className="flex items-center gap-2">
              <div className="w-1 h-6 rounded-full bg-[#1565C0]" />
              <h2 className="font-semibold text-gray-900">症状自测</h2>
              {selectedSymptoms.size > 0 && (
                <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                  已选 {selectedSymptoms.size} 项
                </span>
              )}
            </div>
            {expandedSection === "symptoms" ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </button>
          <AnimatePresence>
            {expandedSection === "symptoms" && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-4 pb-4 space-y-2">
                  <p className="text-sm text-gray-500 mb-3">请勾选您目前出现的症状：</p>
                  {symptoms.map((s) => (
                    <label
                      key={s.id}
                      className={`flex items-start gap-3 p-3 rounded-lg border transition-all cursor-pointer ${
                        selectedSymptoms.has(s.id)
                          ? "border-[#1565C0] bg-blue-50/50"
                          : "border-gray-100 hover:border-gray-200"
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedSymptoms.has(s.id)}
                        onChange={() => toggleSymptom(s.id)}
                        className="mt-0.5 w-4 h-4 rounded border-gray-300 text-[#1565C0] focus:ring-[#1565C0]"
                      />
                      <div>
                        <span className="text-sm font-medium text-gray-800">{s.label}</span>
                        <p className="text-xs text-gray-400 mt-0.5">{s.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Lab Reference */}
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          <button
            onClick={() => toggleSection("labs")}
            className="w-full flex items-center justify-between p-4 text-left"
          >
            <div className="flex items-center gap-2">
              <div className="w-1 h-6 rounded-full bg-[#2E7D32]" />
              <h2 className="font-semibold text-gray-900">复查指标参考</h2>
            </div>
            {expandedSection === "labs" ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </button>
          <AnimatePresence>
            {expandedSection === "labs" && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-4 pb-4">
                  <p className="text-sm text-gray-500 mb-3">以下为感染性结石患者随访常规检查指标及参考范围：</p>
                  <div className="space-y-2">
                    {labItems.map((item) => (
                      <div key={item.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm text-gray-700 font-medium">{item.name}</span>
                        <span className="text-sm text-[#1565C0] font-semibold">
                          {item.normal} {item.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                    <p className="text-xs text-[#1565C0]">
                      <strong>随访检查建议：</strong>每次随访均应进行尿常规检查；出现感染征象时需立即送检尿培养；建议在治疗后6个月内完成首次24小时尿液代谢分析。
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Risk Assessment */}
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          <button
            onClick={() => toggleSection("risk")}
            className="w-full flex items-center justify-between p-4 text-left"
          >
            <div className="flex items-center gap-2">
              <div className="w-1 h-6 rounded-full bg-[#F57C00]" />
              <h2 className="font-semibold text-gray-900">风险分级评估</h2>
            </div>
            {expandedSection === "risk" ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </button>
          <AnimatePresence>
            {expandedSection === "risk" && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-4 pb-4 space-y-3">
                  <p className="text-sm text-gray-500">根据您勾选的症状进行风险评估：</p>
                  <div className="p-3 bg-amber-50 rounded-lg border border-amber-100">
                    <p className="text-xs text-amber-700">
                      <strong>高风险因素包括：</strong>残留结石碎片＞4mm、合并复杂性尿路感染、代谢异常、术前eGFR＜60 mL/min/1.73m²、正在接受预防性药物治疗等。
                    </p>
                  </div>
                  <Button
                    onClick={() => setShowResult(true)}
                    className="w-full bg-gradient-to-r from-[#1565C0] to-[#1976D2] hover:from-[#0D47A1] hover:to-[#1565C0] text-white py-3"
                  >
                    开始评估
                  </Button>

                  {showResult && risk && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`p-4 rounded-xl border ${riskConfig[risk].bg} ${riskConfig[risk].border}`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        {(() => {
                          const Icon = riskConfig[risk].icon;
                          return <Icon className={`w-5 h-5 ${riskConfig[risk].color}`} />;
                        })()}
                        <span className={`font-bold text-lg ${riskConfig[risk].color}`}>
                          {riskConfig[risk].label}
                        </span>
                      </div>
                      <p className={`text-sm ${riskConfig[risk].color}`}>
                        {riskConfig[risk].advice}
                      </p>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Follow-up Schedule Reference */}
        <div className="bg-white rounded-xl border border-gray-100 p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-[#7B1FA2]" />
            <h2 className="font-semibold text-gray-900">随访时间表</h2>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-start gap-3 p-2">
              <div className="w-2 h-2 rounded-full bg-[#1565C0] mt-1.5 flex-shrink-0" />
              <div>
                <span className="font-medium text-gray-800">治疗后第1年：</span>
                <span className="text-gray-600">1周、1个月、3个月各随访1次，之后每3个月随访1次</span>
              </div>
            </div>
            <div className="flex items-start gap-3 p-2">
              <div className="w-2 h-2 rounded-full bg-[#1976D2] mt-1.5 flex-shrink-0" />
              <div>
                <span className="font-medium text-gray-800">治疗后第2年：</span>
                <span className="text-gray-600">每6个月随访一次</span>
              </div>
            </div>
            <div className="flex items-start gap-3 p-2">
              <div className="w-2 h-2 rounded-full bg-[#42A5F5] mt-1.5 flex-shrink-0" />
              <div>
                <span className="font-medium text-gray-800">2年后：</span>
                <span className="text-gray-600">可延长至每年随访一次</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BottomBar />
    </div>
  );
}
