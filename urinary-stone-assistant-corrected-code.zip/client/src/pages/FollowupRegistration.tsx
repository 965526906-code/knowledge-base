/*
 * Design: Warm Guardian - 随访登记系统
 * 功能：基本信息、手术相关指标、临床随访记录、护理随访记录
 */
import { useState } from "react";
import { motion } from "framer-motion";
import {
  ClipboardList, User, Stethoscope, FileText, Heart,
  Save, Plus, ChevronRight
} from "lucide-react";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type TabId = "basic" | "surgery" | "clinical" | "nursing";

interface TabConfig {
  id: TabId;
  label: string;
  icon: React.ElementType;
  color: string;
}

const tabs: TabConfig[] = [
  { id: "basic", label: "基本信息", icon: User, color: "text-[#1565C0]" },
  { id: "surgery", label: "手术指标", icon: Stethoscope, color: "text-[#2E7D32]" },
  { id: "clinical", label: "临床随访", icon: FileText, color: "text-[#E65100]" },
  { id: "nursing", label: "护理随访", icon: Heart, color: "text-[#7B1FA2]" },
];

function FormField({ label, type = "text", placeholder, options, required }: {
  label: string;
  type?: string;
  placeholder?: string;
  options?: string[];
  required?: boolean;
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium text-gray-700">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {type === "select" && options ? (
        <select className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] transition-colors">
          <option value="">{placeholder || "请选择"}</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      ) : type === "textarea" ? (
        <textarea
          className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] transition-colors resize-none"
          rows={3}
          placeholder={placeholder}
        />
      ) : (
        <input
          type={type}
          className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] transition-colors"
          placeholder={placeholder}
        />
      )}
    </div>
  );
}

function CheckboxGroup({ label, options }: { label: string; options: string[] }) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium text-gray-700">{label}</label>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => (
          <label key={opt} className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-sm cursor-pointer hover:bg-blue-50 hover:border-[#1565C0]/30 transition-colors">
            <input type="checkbox" className="w-3.5 h-3.5 rounded text-[#1565C0]" />
            <span>{opt}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

function BasicInfoTab() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <FormField label="姓名" placeholder="请输入姓名" required />
        <FormField label="性别" type="select" options={["男", "女"]} required />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <FormField label="年龄" type="number" placeholder="岁" required />
        <FormField label="患者住院ID" placeholder="住院号" required />
      </div>
      <FormField label="联系方式" type="tel" placeholder="手机号码" required />
      <div className="grid grid-cols-2 gap-3">
        <FormField label="身高" type="number" placeholder="cm" />
        <FormField label="体重" type="number" placeholder="kg" />
      </div>
      <FormField label="职业" placeholder="请输入职业" />
      <FormField label="手术时间" type="date" />
      <FormField label="手术方式" type="select" options={["经皮肾镜取石术(PCNL)", "输尿管软镜碎石术(FURL)", "体外冲击波碎石术(ESWL)", "开放手术", "其他"]} />
      <FormField label="结石成分" type="select" options={["磷酸铵镁结石(鸟粪石)", "碳酸磷灰石", "混合性感染结石", "待分析", "其他"]} />
      <FormField label="饮水量(L/日)" type="number" placeholder="例如：2.5" />
      <div className="grid grid-cols-2 gap-3">
        <FormField label="责任医生" placeholder="医生姓名" />
        <FormField label="随访护士" placeholder="护士姓名" />
      </div>
      <FormField label="饮食偏好" type="select" options={["无特殊嗜好", "高盐饮食", "高蛋白饮食", "高嘌呤饮食", "其他"]} />
      <CheckboxGroup label="生活习惯" options={["吸烟", "饮酒", "无"]} />
      <CheckboxGroup label="既往史" options={["高血压", "糖尿病", "肾功能不全", "痛风", "其他"]} />
      <FormField label="结石发现方法" type="select" options={["体检", "腰痛", "血尿", "发热", "其他"]} />
      <FormField label="既往泌尿系感染性结石病原体" type="textarea" placeholder="请填写既往培养出的病原体" />
      <FormField label="既往感染用药" type="textarea" placeholder="请填写既往使用的抗菌药物" />
      <FormField label="首次泌尿系感染性结石时间" type="date" />
      <FormField label="反复泌尿系感染性结石" type="select" options={["是", "否"]} />
    </div>
  );
}

function SurgeryTab() {
  return (
    <div className="space-y-4">
      <FormField label="手术日期" type="date" required />
      <FormField label="手术方式" type="select" options={["经皮肾镜取石术(PCNL)", "输尿管软镜碎石术(FURL)", "体外冲击波碎石术(ESWL)", "SMP微创经皮肾镜", "开放手术", "其他"]} required />
      <FormField label="结石位置" type="select" options={["左肾", "右肾", "双肾", "左输尿管", "右输尿管", "膀胱", "多发"]} />
      <FormField label="结石大小(mm)" type="number" placeholder="最大径" />
      <FormField label="结石清除情况" type="select" options={["完全清除", "残留≤4mm", "残留>4mm"]} />
      <FormField label="术后并发症" type="textarea" placeholder="出血、感染、输尿管损伤等" />
      <FormField label="输尿管支架管" type="select" options={["已留置", "未留置", "已拔除"]} />
      <FormField label="术后尿培养结果" type="textarea" placeholder="培养结果及药敏" />
      <FormField label="结石成分分析" type="textarea" placeholder="结石成分分析结果" />
      <FormField label="术后用药方案" type="textarea" placeholder="抗菌药物、脲酶抑制剂等" />
    </div>
  );
}

function ClinicalFollowupTab() {
  return (
    <div className="space-y-4">
      <FormField label="随访日期" type="date" required />
      <FormField label="随访时间点" type="select" options={["术后1周", "术后1个月", "术后3个月", "术后6个月", "术后9个月", "术后12个月", "术后18个月", "术后24个月", "其他"]} required />
      <div className="p-3 bg-blue-50 rounded-lg">
        <h4 className="text-sm font-semibold text-[#1565C0] mb-2">症状评估</h4>
        <CheckboxGroup label="" options={["发热", "腰痛", "血尿", "尿频尿急", "尿痛", "恶心呕吐", "无明显症状"]} />
      </div>
      <div className="p-3 bg-green-50 rounded-lg">
        <h4 className="text-sm font-semibold text-[#2E7D32] mb-2">实验室检查</h4>
        <div className="space-y-3">
          <FormField label="尿常规结果" type="textarea" placeholder="WBC、亚硝酸盐、pH等" />
          <FormField label="尿培养结果" type="textarea" placeholder="培养结果及药敏" />
          <FormField label="血液检查" type="textarea" placeholder="肝肾功能、电解质等" />
          <FormField label="24h尿液分析" type="textarea" placeholder="尿量、钙、草酸、枸橼酸等" />
        </div>
      </div>
      <div className="p-3 bg-orange-50 rounded-lg">
        <h4 className="text-sm font-semibold text-[#E65100] mb-2">影像学检查</h4>
        <FormField label="检查方式" type="select" options={["肾脏超声", "腹部X线(KUB)", "超声+KUB", "非增强CT", "其他"]} />
        <div className="mt-2">
          <FormField label="检查结果" type="textarea" placeholder="结石情况、肾积水、梗阻等" />
        </div>
      </div>
      <FormField label="药物调整" type="textarea" placeholder="药物方案调整记录" />
      <FormField label="处理意见" type="textarea" placeholder="医生处理意见及下次随访安排" />
    </div>
  );
}

function NursingFollowupTab() {
  return (
    <div className="space-y-4">
      <FormField label="随访日期" type="date" required />
      <FormField label="随访方式" type="select" options={["门诊", "电话", "微信", "APP/小程序", "其他"]} required />
      <div className="p-3 bg-purple-50 rounded-lg">
        <h4 className="text-sm font-semibold text-[#7B1FA2] mb-2">生活方式评估</h4>
        <div className="space-y-3">
          <FormField label="每日饮水量(L)" type="number" placeholder="例如：2.5" />
          <FormField label="每日尿量(L)" type="number" placeholder="例如：2.0" />
          <FormField label="饮食依从性" type="select" options={["良好", "一般", "较差"]} />
          <FormField label="运动情况" type="select" options={["规律运动(每周≥5次)", "偶尔运动", "基本不运动"]} />
          <FormField label="BMI" type="number" placeholder="体重指数" />
        </div>
      </div>
      <div className="p-3 bg-blue-50 rounded-lg">
        <h4 className="text-sm font-semibold text-[#1565C0] mb-2">用药依从性</h4>
        <FormField label="药物依从性" type="select" options={["完全依从", "部分依从", "不依从"]} />
        <div className="mt-2">
          <FormField label="用药情况说明" type="textarea" placeholder="是否按时服药、有无副作用等" />
        </div>
      </div>
      <FormField label="健康教育内容" type="textarea" placeholder="本次宣教的主要内容" />
      <FormField label="患者反馈" type="textarea" placeholder="患者的疑问和反馈" />
      <FormField label="护理评估总结" type="textarea" placeholder="整体评估及建议" />
    </div>
  );
}

export default function FollowupRegistration() {
  const [activeTab, setActiveTab] = useState<TabId>("basic");

  const handleSave = () => {
    toast.success("随访信息已保存", {
      description: "数据已成功记录到系统中",
    });
  };

  const tabContent: Record<TabId, React.ReactNode> = {
    basic: <BasicInfoTab />,
    surgery: <SurgeryTab />,
    clinical: <ClinicalFollowupTab />,
    nursing: <NursingFollowupTab />,
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F7FA]">
      <Header />

      {/* Title Bar */}
      <div className="bg-gradient-to-r from-[#E65100] to-[#F57C00] px-4 py-4">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <ClipboardList className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">随访登记系统</h1>
            <p className="text-xs text-white/80">患者随访信息录入与管理</p>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-100 sticky top-[52px] z-40">
        <div className="max-w-lg mx-auto px-2 flex overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "border-[#F57C00] text-[#E65100]"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Form Content */}
      <div className="max-w-lg mx-auto px-4 py-4 pb-24 w-full">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
        >
          {tabContent[activeTab]}
        </motion.div>

        {/* Action Buttons */}
        <div className="mt-6 flex gap-3">
          <Button
            onClick={handleSave}
            className="flex-1 bg-gradient-to-r from-[#1565C0] to-[#1976D2] hover:from-[#0D47A1] hover:to-[#1565C0] text-white py-3"
          >
            <Save className="w-4 h-4 mr-2" />
            保存记录
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-[#F57C00] text-[#E65100] hover:bg-orange-50 py-3"
            onClick={() => {
              toast.info("功能提示", { description: "新建登记表功能即将上线" });
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            新建登记
          </Button>
        </div>

        {/* Health Education Quick Link */}
        <div className="mt-4 bg-blue-50 rounded-xl p-4 border border-blue-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-[#1565C0]" />
              <span className="text-sm font-medium text-[#1565C0]">健康教育知识宣教</span>
            </div>
            <a href="/knowledge" className="flex items-center gap-1 text-xs text-[#F57C00] font-medium">
              查看详情 <ChevronRight className="w-3.5 h-3.5" />
            </a>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            随访时请同步进行健康教育，包括饮食指导、液体摄入管理、运动建议等内容。
          </p>
        </div>
      </div>
    </div>
  );
}
