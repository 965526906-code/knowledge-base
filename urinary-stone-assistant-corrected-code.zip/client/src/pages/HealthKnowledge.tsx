/*
 * Design: Warm Guardian - 健康知识模块
 * 基于《泌尿系感染性结石患者随访管理的最佳证据总结》
 * 涵盖：饮食干预、酸化尿液指导、预防复发知识等8大证据类别
 * 纯白背景，无背景图
 */
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen, Droplets, Apple, Pill, Scan, HeartPulse, Dumbbell,
  ChevronDown, ChevronUp, GlassWater, AlertCircle, RefreshCw
} from "lucide-react";
import Header from "@/components/Header";
import BottomBar from "@/components/BottomBar";

interface KnowledgeCategory {
  id: string;
  title: string;
  icon: React.ElementType;
  color: string;
  iconBg: string;
  items: { title: string; content: string }[];
}

const categories: KnowledgeCategory[] = [
  {
    id: "followup",
    title: "\u968f\u8bbf\u8ba1\u5212\u4e0e\u65b9\u5f0f",
    icon: HeartPulse,
    color: "text-[#1565C0]",
    iconBg: "bg-blue-50",
    items: [
      {
        title: "\u5e38\u89c4\u968f\u8bbf\u5468\u671f",
        content: "\u6cbb\u7597\u7ed3\u675f\u540e1\u5468\u30011\u4e2a\u6708\u30013\u4e2a\u6708\u5404\u968f\u8bbf1\u6b21\uff0c\u4e4b\u540e\u6bcf3\u4e2a\u6708\u968f\u8bbf1\u6b21\uff0c\u6301\u7eed1\u5e74\uff1b\u7b2c2\u5e74\u6bcf6\u4e2a\u6708\u968f\u8bbf\u4e00\u6b21\uff1b2\u5e74\u540e\u53ef\u5ef6\u957f\u81f3\u6bcf\u5e74\u968f\u8bbf\u4e00\u6b21\u3002",
      },
      {
        title: "\u9ad8\u98ce\u9669\u60a3\u8005\u5f3a\u5316\u968f\u8bbf",
        content: "\u5b58\u5728\u4ee5\u4e0b\u98ce\u9669\u56e0\u7d20\u9700\u7f29\u77ed\u968f\u8bbf\u95f4\u9694\uff1a\u2460\u6b8b\u7559\u7ed3\u77f3\u788e\u7247\uff1e4mm\u6216\u672f\u540e\u6b8b\u7559\u8f83\u591a\uff1b\u2461\u5408\u5e76\u590d\u6742\u6027\u5c3f\u8def\u611f\u67d3\u6216\u4ee3\u8c22\u5f02\u5e38\uff1b\u2462\u672f\u524deGFR\uff1c60 mL/min/1.73m\u00b2\uff1b\u2463\u6b63\u5728\u63a5\u53d7\u9884\u9632\u6027\u836f\u7269\u6cbb\u7597\u3002",
      },
      {
        title: "\u968f\u8bbf\u5f62\u5f0f",
        content: "\u53ef\u901a\u8fc7\u95e8\u8bca\u968f\u8bbf\u3001\u7535\u8bdd\u968f\u8bbf\u3001\u95ee\u5377\u8c03\u67e5\u7b49\u591a\u79cd\u5f62\u5f0f\u5b9e\u73b0\u3002\u79ef\u6781\u5229\u7528\u8fdc\u7a0b\u533b\u7597\u53ca\u5fae\u4fe1\u7fa4\u3001\u624b\u673aAPP\u6216\u5c0f\u7a0b\u5e8f\u7b49\u7ebf\u4e0a\u5e73\u53f0\u8fdb\u884c\u60a3\u8005\u7ba1\u7406\u3001\u6559\u80b2\u4e0e\u968f\u8bbf\u3002",
      },
    ],
  },
  {
    id: "assessment",
    title: "\u4e34\u5e8a\u7efc\u5408\u8bc4\u4f30",
    icon: Scan,
    color: "text-[#7B1FA2]",
    iconBg: "bg-purple-50",
    items: [
      {
        title: "\u6574\u4f53\u72b6\u51b5\u8bc4\u4f30",
        content: "\u8bc4\u4f30\u996e\u98df\u3001\u75bc\u75db\u3001\u8f93\u5c3f\u7ba1\u652f\u67b6\u7ba1\u7559\u7f6e\u72b6\u6001\u3001\u7efc\u5408\u4ee3\u8c22\u72b6\u6001\u3002",
      },
      {
        title: "\u6cbb\u7597\u76f8\u5173\u5e76\u53d1\u75c7\u8bc4\u4f30",
        content: "\u8bc4\u4f30\u624b\u672f\u5e72\u9884\u540e\u7684\u6f5c\u5728\u5e76\u53d1\u75c7\uff0c\u5305\u62ec\u51fa\u8840\u3001\u8113\u6bd2\u75c7\u3001\u8f93\u5c3f\u7ba1\u635f\u4f24\u3001\u90bb\u8fd1\u810f\u5668\u635f\u4f24\u3001\u6c14\u80f8\u3001\u8f93\u5c3f\u7ba1\u72ed\u7a84\u7b49\u3002",
      },
      {
        title: "\u5408\u5e76\u75c7\u8bc4\u4f30",
        content: "\u8bc4\u4f30\u76f8\u5173\u5408\u5e76\u75be\u75c5\u7684\u63a7\u5236\u6548\u679c\uff0c\u5982\u5c3f\u8def\u611f\u67d3\u3001\u7cd6\u5c3f\u75c5\u3001\u5c3f\u8def\u68b3\u963b\u3001\u795e\u7ecf\u6e90\u6027\u8180\u80f1\u3001\u8fdc\u7aef\u80be\u5c0f\u7ba1\u9178\u4e2d\u6bd2\u53ca\u9ad3\u8d28\u6d77\u7ef5\u80be\u7b49\u3002",
      },
    ],
  },
  {
    id: "lab",
    title: "\u5b9e\u9a8c\u5ba4\u68c0\u67e5",
    icon: Droplets,
    color: "text-[#00838F]",
    iconBg: "bg-cyan-50",
    items: [
      {
        title: "\u5c3f\u5e38\u89c4\u76d1\u6d4b",
        content: "\u6bcf\u6b21\u968f\u8bbf\u5747\u5e94\u8fdb\u884c\u5c3f\u5e38\u89c4\u68c0\u67e5\uff0c\u76d1\u6d4b\u767d\u7ec6\u80de\u916f\u9176\u3001\u4e9a\u785d\u9178\u76d0\u7b49\u5c3f\u8def\u611f\u67d3\u6807\u5fd7\u7269\u3002\u5efa\u8bae\u5c06\u5c3f\u6db2pH\u7ef4\u6301\u57286.2\u5de6\u53f3\uff0c\u4ee5\u6291\u5236\u7ed3\u77f3\u5f62\u6210\u5e76\u63a7\u5236\u611f\u67d3\u3002",
      },
      {
        title: "\u5c3f\u57f9\u517b\u76d1\u6d4b",
        content: "\u51fa\u73b0\u611f\u67d3\u5f81\u8c61\u65f6\u9700\u7acb\u5373\u9001\u68c0\u3002\u957f\u671f\u6297\u83cc\u836f\u7269\u9884\u9632\u671f\u95f4\uff0c\u5efa\u8bae\u6bcf\u6708\u8fdb\u884c1\u6b21\u5c3f\u57f9\u517b\u5e76\u6301\u7eed3\u4e2a\u6708\uff1b\u505c\u836f\u540e\u4ecd\u9700\u6bcf\u6708\u590d\u67e51\u6b21\u3001\u8fde\u7eed3\u4e2a\u6708\u4ee5\u76d1\u6d4b\u611f\u67d3\u590d\u53d1\u3002",
      },
      {
        title: "24\u5c0f\u65f6\u5c3f\u6db2\u4ee3\u8c22\u5206\u6790",
        content: "\u6838\u5fc3\u68c0\u6d4b\u9879\u76ee\u5305\u62ec\u5c3f\u91cf\u3001\u9499\u3001\u8349\u9178\u3001\u67b8\u6a7c\u9178\u3001\u5c3f\u9178\u548c\u808c\u9150\uff0c\u53ef\u9009\u6d4bpH\u3001\u9541\u3001\u94a0\u3001\u94be\u7b49\u3002\u5efa\u8bae\u5728\u6cbb\u7597\u5f00\u59cb\u540e6\u4e2a\u6708\u5185\u5b8c\u6210\u9996\u6b21\u5206\u6790\u3002",
      },
      {
        title: "\u8840\u6db2\u68c0\u67e5",
        content: "\u63a5\u53d7\u836f\u7269\u6cbb\u7597\u7684\u60a3\u8005\u9700\u5b9a\u671f\u68c0\u67e5\u809d\u80be\u529f\u80fd\u3001\u7535\u89e3\u8d28\uff08\u94a0\u3001\u94be\u3001\u6c2f\u3001\u9499\u3001\u78f7\u3001\u9541\uff09\u3001\u8840\u7cd6\u3001\u8840\u8102\u3001\u8840\u5c3f\u9178\u3001\u7532\u72b6\u65c1\u817a\u6fc0\u7d20\u7b49\u3002",
      },
    ],
  },
  {
    id: "imaging",
    title: "\u5f71\u50cf\u5b66\u68c0\u67e5",
    icon: Scan,
    color: "text-[#E65100]",
    iconBg: "bg-orange-50",
    items: [
      {
        title: "\u68c0\u67e5\u76ee\u7684",
        content: "\u76d1\u6d4b\u7ed3\u77f3\u590d\u53d1\u3001\u73b0\u6709\u7ed3\u77f3\u751f\u957f\u3001\u6b8b\u7559\u7ed3\u77f3\u788e\u7247\u4ee5\u53ca\u5c3f\u8def\u68b3\u963b\u60c5\u51b5\u3002",
      },
      {
        title: "\u68c0\u67e5\u65f6\u673a",
        content: "\u6cbb\u7597\u540e6\u4e2a\u6708\u5185\u8fdb\u884c\u9996\u6b21\u5f71\u50cf\u5b66\u590d\u67e5\uff1b\u624b\u672f\u60a3\u8005\u672f\u540e2-3\u4e2a\u6708\u5185\u5b8c\u6210\u9996\u6b21\u68c0\u67e5\uff1b\u6b64\u540e\u6bcf6-12\u4e2a\u6708\u8fdb\u884c\u4f8b\u884c\u76d1\u6d4b\u3002",
      },
      {
        title: "\u68c0\u67e5\u65b9\u5f0f",
        content: "\u9996\u9009\u80be\u810f\u8d85\u58f0\uff08\u65e0\u8f90\u5c04\uff0c\u53ef\u8bc4\u4f30\u80be\u79ef\u6c34\u4e0e\u80be\u810f\u4f53\u79ef\uff09\uff0c\u5e38\u4e0e\u8179\u90e8X\u7ebf\uff08KUB\uff09\u8054\u5408\u4f7f\u7528\u3002\u975e\u589e\u5f3aCT\u4ec5\u63a8\u8350\u7528\u4e8e\u75c7\u72b6\u53d1\u4f5c\u65f6\u6216\u518d\u6b21\u624b\u672f\u524d\u7684\u7cbe\u786e\u8bc4\u4f30\u3002",
      },
    ],
  },
  {
    id: "medication",
    title: "\u836f\u7269\u6cbb\u7597\u76d1\u6d4b",
    icon: Pill,
    color: "text-[#AD1457]",
    iconBg: "bg-pink-50",
    items: [
      {
        title: "\u6297\u83cc\u836f\u7269\u76d1\u6d4b",
        content: "\u672f\u540e\u5e94\u6839\u636e\u75c5\u539f\u5b66\u57f9\u517b\u53ca\u836f\u654f\u8bd5\u9a8c\u7ed3\u679c\u9009\u62e9\u654f\u611f\u6297\u751f\u7d20\u8fdb\u884c\u957f\u671f\u6cbb\u7597\uff0c\u671f\u95f4\u9700\u6bcf\u6708\u590d\u67e5\u5c3f\u57f9\u517b\uff0c\u5e76\u6839\u636e\u7ed3\u679c\u8c03\u6574\u7528\u836f\u65b9\u6848\u3002",
      },
      {
        title: "\u8132\u9176\u6291\u5236\u5242\u76d1\u6d4b",
        content: "\u8132\u9176\u6291\u5236\u5242\u53ef\u6291\u5236\u611f\u67d3\u6027\u7ed3\u77f3\u7684\u751f\u957f\u3002\u63a8\u8350\u5242\u91cf\u4e3a250mg\u3001\u6bcf\u65e52\u6b21\uff1b\u6cbb\u75972\u5468\u540e\u53ca\u540e\u7eed\u6bcf3\u4e2a\u6708\u5b9a\u671f\u590d\u67e5\u5168\u8840\u7ec6\u80de\u8ba1\u6570\u4e0e\u809d\u529f\u80fd\u3002",
      },
      {
        title: "\u5176\u4ed6\u8f85\u52a9\u836f\u7269",
        content: "\u8bc4\u4f30\u5c3f\u6db2\u9178\u5316\u836f\u7269\u7684\u4ee3\u8c22\u6027\u526f\u4f5c\u7528\uff1b\u564f\u55ea\u7c7b\u5229\u5c3f\u5242/\u67b8\u6a7c\u9178\u94be\u9700\u76d1\u6d4b\u8840\u94be\uff1b\u522b\u5606\u9187/\u786b\u666e\u7f57\u5b81\u9700\u76d1\u6d4b\u809d\u529f\u80fd\uff1b\u9752\u9709\u80fa\u9700\u76d1\u6d4b\u80be\u529f\u80fd\u3002",
      },
    ],
  },
  {
    id: "diet",
    title: "\u996e\u98df\u5e72\u9884\u4e0e\u6db2\u4f53\u6444\u5165",
    icon: Apple,
    color: "text-[#2E7D32]",
    iconBg: "bg-green-50",
    items: [
      {
        title: "\u6db2\u4f53\u6444\u5165\u7ba1\u7406",
        content: "\u5e94\u589e\u52a0\u6db2\u4f53\u6444\u5165\uff0c\u5b9e\u73b0\u6bcf\u65e5\u5c3f\u91cf\u22652.0-2.5L\uff0c\u6bcf\u65e5\u6db2\u4f53\u6444\u5165\u91cf\u901a\u5e38\u9700\u8fbe\u52302.5-3.0L\u3002\u6444\u5165\u5e94\u5747\u5300\u5206\u5e03\u5168\u5929\uff0c\u51fa\u6c57\u6216\u8179\u6cfb\u65f6\u9700\u989d\u5916\u8865\u5145\u3002\u6c34\u662f\u9996\u9009\u996e\u54c1\u3002",
      },
      {
        title: "\u9178\u5316\u5c3f\u6db2\u6307\u5bfc",
        content: "\u4e3a\u8f85\u52a9\u9178\u5316\u5c3f\u6db2\uff0c\u53ef\u996e\u7528\u9752\u6885\u679c\u6c41\u3001\u8513\u8d8a\u8393\u6c41\u7b49\u9178\u6027\u996e\u6599\uff0c\u5e76\u907f\u514d\u996e\u7528\u4f7f\u5c3f\u6db2\u78b1\u5316\u7684\u996e\u6599\uff08\u5982\u6a59\u6c41\u3001\u53ef\u4e50\uff09\u3002\u5efa\u8bae\u5c06\u5c3f\u6db2pH\u7ef4\u6301\u57286.2\u5de6\u53f3\u3002",
      },
      {
        title: "\u81b3\u98df\u7ba1\u7406",
        content: "\u2460\u94a0\u76d0\uff1a\u9650\u5236\uff1c5-6g/\u5929\uff1b\u2461\u9499\uff1a\u63a8\u83501000-1200mg/\u5929\uff0c\u968f\u9910\u670d\u7528\uff1b\u2462\u52a8\u7269\u86cb\u767d\uff1a\u9650\u52360.8-1.0g/kg/\u5929\uff1b\u2463\u589e\u52a0\u6c34\u679c\u3001\u852c\u83dc\u53ca\u7ea4\u7ef4\u7d20\u6444\u5165\uff1b\u2464\u7ef4\u751f\u7d20C\u4e0d\u8d85\u8fc71000mg/\u5929\u3002",
      },
      {
        title: "\u63a8\u8350\u996e\u98df\u6a21\u5f0f",
        content: "\u63a8\u8350\u91c7\u7528DASH\u996e\u98df\u3001\u5730\u4e2d\u6d77\u81b3\u98df\uff08\u4ee5\u690d\u7269\u6027\u98df\u7269\u4e3a\u4e3b\u3001\u9002\u91cf\u8089\u7c7b\uff09\u6216\u5747\u8861\u7684\u7d20\u98df\u996e\u98df\uff08\u53ef\u5305\u542b\u4e73\u5236\u54c1\uff0c\u4f46\u4e0d\u63a8\u8350\u7eaf\u7d20\u996e\u98df\uff09\u3002",
      },
    ],
  },
  {
    id: "lifestyle",
    title: "\u4f53\u91cd\u4e0e\u8fd0\u52a8\u7ba1\u7406",
    icon: Dumbbell,
    color: "text-[#4527A0]",
    iconBg: "bg-indigo-50",
    items: [
      {
        title: "\u4f53\u91cd\u7ba1\u7406",
        content: "\u901a\u8fc7\u996e\u98df\u548c\u8fd0\u52a8\u8fbe\u5230\u5e76\u7ef4\u6301\u6b63\u5e38\u4f53\u91cd\u6307\u6570\uff08BMI\uff09\u3002",
      },
      {
        title: "\u4f53\u529b\u6d3b\u52a8",
        content: "\u4fdd\u6301\u89c4\u5f8b\u5145\u8db3\u7684\u4f53\u529b\u6d3b\u52a8\uff1a\u6bcf\u65e5\u6d3b\u52a8\u91cf\u76f8\u5f53\u4e8e\u884c\u8d706000\u6b65\uff0c\u6216\u6bcf\u5468\u8fdb\u884c\u22655\u6b21\u3001\u6bcf\u6b21\u226530\u5206\u949f\u7684\u4e2d\u7b49\u5f3a\u5ea6\u6709\u6c27\u8fd0\u52a8\uff08\u5982\u5feb\u8d70\u3001\u9a91\u884c\u3001\u6e38\u6cf3\u3001\u821e\u8e48\uff09\uff0c\u8fd0\u52a8\u65f6\u4ee5\u300c\u80fd\u8bf4\u8bdd\u3001\u4e0d\u80fd\u5531\u6b4c\u300d\u4e3a\u5f3a\u5ea6\u53c2\u8003\u3002\u53ef\u914d\u5408\u6bcf\u54682-3\u6b21\u7684\u6297\u963b\u8fd0\u52a8\u3002",
      },
      {
        title: "\u9650\u5236\u9759\u6001\u884c\u4e3a",
        content: "\u9650\u5236\u5a31\u4e50\u6027\u7535\u5b50\u4ea7\u54c1\u4f7f\u7528\u65f6\u95f42-3\u5c0f\u65f6/\u5929\u3002",
      },
    ],
  },
  {
    id: "stone-outcome",
    title: "\u7ed3\u77f3\u8f6c\u5f52\u4e0e\u5e72\u9884",
    icon: RefreshCw,
    color: "text-[#0277BD]",
    iconBg: "bg-sky-50",
    items: [
      {
        title: "\u7ed3\u77f3\u590d\u53d1\u76d1\u6d4b",
        content: "\u8bc4\u4f30\u7ed3\u77f3\u590d\u53d1\u3001\u6b8b\u7559\u788e\u7247\u751f\u957f\u53ca\u5c3f\u8def\u611f\u67d3\uff08UTI\uff09\u518d\u53d1\u60c5\u51b5\uff0c\u5e76\u9700\u7279\u522b\u5173\u6ce8\u662f\u5426\u518d\u6b21\u611f\u67d3\u4ea7\u8132\u9176\u5fae\u751f\u7269\u3002\u82e5\u51fa\u73b0\u7ed3\u77f3\u590d\u53d1\uff0c\u5efa\u8bae\u5c3d\u53ef\u80fd\u91cd\u590d\u8fdb\u884c\u7ed3\u77f3\u6210\u5206\u5206\u6790\u4ee5\u6307\u5bfc\u6cbb\u7597\u3002",
      },
      {
        title: "\u518d\u5e72\u9884\u6807\u51c6",
        content: "\uff081\uff09\u4e3b\u8981\u5e72\u9884\u6307\u5f81\uff1a\u51fa\u73b0\u590d\u53d1\u6027\u5c3f\u8def\u611f\u67d3\uff08UTI\uff09\u6216\u7ed3\u77f3\u751f\u957f\u65f6\uff0c\u901a\u5e38\u9700\u8003\u8651\u518d\u6b21\u5185\u955c\u624b\u672f\u6e05\u9664\u3002\uff082\uff09\u6b8b\u77f3\u5904\u7406\u5171\u8bc6\uff1a\u5bf9\u4e8e\u6b8b\u77f3>4mm\u7684\u60a3\u8005\uff0c\u5efa\u8bae\u62e9\u671f\u518d\u5e72\u9884\uff1b\u5373\u4f7f\u6b8b\u77f3\u22644mm\uff0c\u90e8\u5206\u60a3\u8005\u6839\u636e\u5176\u5177\u4f53\u60c5\u51b5\u4e5f\u53ef\u80fd\u9700\u8981\u518d\u5e72\u9884\uff1b\u672f\u540e\u5b58\u5728\u6b8b\u77f3\u65f6\uff0c\u53ef\u9002\u5f53\u653e\u5bbd\u4e8c\u6b21\u624b\u672f\u6307\u5f81\uff1b\u5171\u8bc6\u5c06\u7ed3\u77f3\u6e05\u9664\u7387\u8fbe80%\u4f5c\u4e3a\u53ef\u8003\u8651\u7ed3\u675f\u968f\u8bbf\u7684\u5b89\u5168\u9608\u503c\u3002",
      },
      {
        title: "\u6b8b\u77f3\u8f85\u52a9\u6cbb\u7597",
        content: "\u5bf9\u4e8e\u5b58\u5728\u6b8b\u7559\u7ed3\u77f3\u788e\u7247\u7684\u60a3\u8005\uff0c\u63a8\u8350\u91c7\u7528\u5c3f\u6db2\u9178\u5316\u53ca\u8132\u9176\u6291\u5236\u5242\u8fdb\u884c\u8f85\u52a9\u6cbb\u7597\uff0c\u4ee5\u63a7\u5236\u611f\u67d3\u5e76\u6291\u5236\u7ed3\u77f3\u751f\u957f\u3002",
      },
    ],
  },
];

export default function HealthKnowledge() {
  const [expandedId, setExpandedId] = useState<string | null>("followup");

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Page Title - 纯白背景，无背景图 */}
      <div className="bg-white px-4 pt-6 pb-4 max-w-lg mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-[#2E7D32]" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{"\u5065\u5eb7\u77e5\u8bc6"}</h1>
            <p className="text-sm text-gray-500">{"\u57fa\u4e8e\u5faa\u8bc1\u533b\u5b66\u76848\u5927\u8bc1\u636e\u7c7b\u522b"}</p>
          </div>
        </div>
        <div className="mt-3 h-[1px] bg-gray-100" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-2 pb-28 w-full space-y-3 bg-white">
        {/* Quick Tips */}
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
          <div className="flex items-start gap-3">
            <GlassWater className="w-8 h-8 text-[#1565C0] flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-[#1565C0] text-sm">{"\u6bcf\u65e5\u996e\u6c34\u5c0f\u8d34\u58eb"}</h3>
              <p className="text-xs text-gray-600 mt-1">
                {"\u6bcf\u65e5\u6db2\u4f53\u6444\u5165\u91cf\u9700\u8fbe\u52302.5-3.0L\uff0c\u4fdd\u8bc1\u5c3f\u91cf\u22652.0-2.5L\u3002\u5747\u5300\u5206\u5e03\u5728\u5168\u5929\uff0c\u6c34\u662f\u9996\u9009\u996e\u54c1\u3002"}
              </p>
            </div>
          </div>
        </div>

        {/* Knowledge Categories */}
        {categories.map((cat) => (
          <div key={cat.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden">
            <button
              onClick={() => setExpandedId(expandedId === cat.id ? null : cat.id)}
              className="w-full flex items-center justify-between p-4 text-left"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${cat.iconBg} flex items-center justify-center flex-shrink-0`}>
                  <cat.icon className={`w-5 h-5 ${cat.color}`} />
                </div>
                <h2 className="font-semibold text-gray-900 text-sm">{cat.title}</h2>
              </div>
              {expandedId === cat.id ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>
            <AnimatePresence>
              {expandedId === cat.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 space-y-3">
                    {cat.items.map((item, idx) => (
                      <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                        <h4 className="text-sm font-semibold text-gray-800 mb-1">{item.title}</h4>
                        <p className="text-xs text-gray-600 leading-relaxed">{item.content}</p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}

        {/* Evidence Source */}
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-[#1565C0] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-[#1565C0] font-medium">{"\u8bc1\u636e\u6765\u6e90"}</p>
              <p className="text-xs text-gray-600 mt-1">
                {"\u4ee5\u4e0a\u5185\u5bb9\u57fa\u4e8e\u300a\u6ccc\u5c3f\u7cfb\u611f\u67d3\u6027\u7ed3\u77f3\u60a3\u8005\u968f\u8bbf\u7ba1\u7406\u7684\u6700\u4f73\u8bc1\u636e\u603b\u7ed3\u300b\uff0c\u7efc\u5408\u4e86\u4e2d\u56fd\u6ccc\u5c3f\u5916\u79d1\u8bca\u7597\u6307\u5357\u3001EAU\u6ccc\u5c3f\u7ed3\u77f3\u6307\u5357\u3001IAU\u4ee3\u8c22\u8bc4\u4f30\u6307\u5357\u7b4919\u7bc7\u6743\u5a01\u6587\u732e\u3002"}
              </p>
            </div>
          </div>
        </div>
      </div>

      <BottomBar />
    </div>
  );
}
