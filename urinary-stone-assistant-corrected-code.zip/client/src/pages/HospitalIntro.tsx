/*
 * Design: Warm Guardian - 医院简介模块
 * 展示广州医科大学附属第一医院泌尿外科简介
 * 纯白背景，无背景图
 */
import { motion } from "framer-motion";
import { Users, Award, BookOpenCheck, Microscope, GraduationCap, Building2 } from "lucide-react";
import Header from "@/components/Header";
import BottomBar from "@/components/BottomBar";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663379302955/mmDvxYoGwM495rh6KFrCar/泌外医学中心_fc9a872d.png";

const highlights = [
  { icon: Award, label: "国家重点专科", value: "卫生部认定" },
  { icon: Users, label: "临床医生", value: "33名" },
  { icon: Microscope, label: "开放床位", value: "268张" },
  { icon: GraduationCap, label: "博士导师", value: "8名" },
];

export default function HospitalIntro() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Page Title - 纯白背景，无背景图 */}
      <div className="bg-white px-4 pt-6 pb-4 max-w-lg mx-auto w-full">
        <div className="flex items-center gap-3">
          <img src={LOGO_URL} alt="泌外医学中心" className="w-14 h-14 rounded-full border-2 border-[#1565C0]/20 shadow-sm" />
          <div>
            <h1 className="text-xl font-bold text-gray-900">广州医科大学附属第一医院</h1>
            <p className="text-sm text-gray-500">泌尿医学中心（泌尿外科）</p>
          </div>
        </div>
        <div className="mt-3 h-[1px] bg-gray-100" />
      </div>

      <div className="max-w-lg mx-auto px-4 py-2 pb-28 w-full space-y-4 bg-white">
        {/* Highlights Grid */}
        <motion.div
          className="grid grid-cols-2 gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {highlights.map((h) => (
            <div key={h.label} className="bg-white rounded-xl p-3 border border-gray-100 text-center">
              <h.icon className="w-6 h-6 text-[#1565C0] mx-auto mb-1" />
              <p className="text-lg font-bold text-gray-900">{h.value}</p>
              <p className="text-xs text-gray-500">{h.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Introduction */}
        <motion.div
          className="bg-white rounded-xl border border-gray-100 p-4 space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1 h-6 rounded-full bg-[#1565C0]" />
            <h2 className="font-semibold text-gray-900">中心简介</h2>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            广州医科大学附属第一医院泌尿医学中心依托于广州医科大学附属第一医院泌尿外科（卫生部国家重点专科）、广东省泌尿外科重点实验室、广州市泌尿外科研究所、广州地区泌尿外科质量控制中心，整合多学科力量，于2022年6月15日挂牌成立。
          </p>
          <p className="text-sm text-gray-600 leading-relaxed">
            中心的名誉主任委员为著名的吴开俊教授和李逊教授，主任委员为著名的曾国华教授和黄锦坤教授，副主任委员为高兴成教授和刘永达教授。中心拥有临床医生33名，其中博士学位20名，博士研究生导师8名，硕士研究生导师13名。
          </p>
        </motion.div>

        {/* Clinical Department */}
        <motion.div
          className="bg-white rounded-xl border border-gray-100 p-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-[#2E7D32]" />
            <h2 className="font-semibold text-gray-900">临床部</h2>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            临床部设有7个病区，开放床位268张，涵盖泌尿系结石、泌尿系肿瘤、尿路修复重建、女性盆底、前列腺与尿控、男科、日间手术、重症医学等8个亚专业。中心拥有11间手术室，其中1间为机器人手术专用手术室。
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <div className="bg-blue-50 rounded-lg p-2 text-center">
              <p className="text-lg font-bold text-[#1565C0]">7200+</p>
              <p className="text-xs text-gray-500">年收治患者(人次)</p>
            </div>
            <div className="bg-green-50 rounded-lg p-2 text-center">
              <p className="text-lg font-bold text-[#2E7D32]">7500+</p>
              <p className="text-xs text-gray-500">年手术量(台次)</p>
            </div>
          </div>
        </motion.div>

        {/* Research */}
        <motion.div
          className="bg-white rounded-xl border border-gray-100 p-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-[#E65100]" />
            <h2 className="font-semibold text-gray-900">科研实力</h2>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            实验部依托于广东省泌尿外科重点实验室、广州市泌尿外科研究所，主要负责泌尿特殊检验检查、泌尿系统疾病的基础与临床研究、设备研发、成果转化等工作。
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {["科研课题76项", "国家级项目21项", "SCI论文188篇", "发明专利11项", "国家科技进步二等奖"].map((tag) => (
              <span key={tag} className="px-2 py-1 bg-orange-50 text-[#E65100] text-xs rounded-full">
                {tag}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Training */}
        <motion.div
          className="bg-white rounded-xl border border-gray-100 p-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-[#7B1FA2]" />
            <h2 className="font-semibold text-gray-900">培训部</h2>
          </div>
          <p className="text-sm text-gray-600 leading-relaxed">
            培训部依托于国际尿石症联盟、国际腔内泌尿外科学会Endourology fellowship项目的培训单位、卫生部泌尿内镜诊疗技术培训基地。自1984年率先开展"全国腔内泌尿外科学习班"以来，共举办国家级培训班208期，培训国内泌尿外科专科医生13919人次，被行内称为"微创泌尿外科技术的黄埔军校"。
          </p>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <div className="bg-purple-50 rounded-lg p-2 text-center">
              <p className="text-base font-bold text-[#7B1FA2]">208期</p>
              <p className="text-xs text-gray-500">国家级培训班</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-2 text-center">
              <p className="text-base font-bold text-[#7B1FA2]">13919</p>
              <p className="text-xs text-gray-500">培训医生(人次)</p>
            </div>
            <div className="bg-purple-50 rounded-lg p-2 text-center">
              <p className="text-base font-bold text-[#7B1FA2]">40国</p>
              <p className="text-xs text-gray-500">国际学员来源</p>
            </div>
          </div>
        </motion.div>

        {/* Mission */}
        <motion.div
          className="bg-gradient-to-r from-[#1565C0] to-[#1976D2] rounded-xl p-4 text-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <BookOpenCheck className="w-5 h-5" />
            <h2 className="font-semibold">奋斗目标</h2>
          </div>
          <p className="text-sm text-white/90 leading-relaxed">
            以泌尿系结石亚专业为龙头，全面发展泌尿外科各亚专业，力争建设成为"世界一流、国内领先"的泌尿医学中心！
          </p>
        </motion.div>
      </div>

      <BottomBar />
    </div>
  );
}
