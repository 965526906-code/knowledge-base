/*
 * Design: Warm Guardian - 人文关怀医疗设计
 * 首页：品牌区 + 功能入口矩阵 + 底部常驻操作栏
 * 纯白/浅灰背景，无背景图
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Activity, BookOpen, ChevronRight, ExternalLink } from "lucide-react";
import Header from "@/components/Header";
import BottomBar from "@/components/BottomBar";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663379302955/mmDvxYoGwM495rh6KFrCar/泌外医学中心_fc9a872d.png";

const features = [
  {
    title: "随访评估",
    desc: "症状自测 · 指标对比 · 风险分级",
    icon: Activity,
    href: "/assessment",
    iconBg: "bg-blue-50",
    iconColor: "text-[#1565C0]",
    borderColor: "border-l-[#1565C0]",
  },
  {
    title: "健康知识",
    desc: "饮食干预 · 酸化尿液 · 预防复发",
    icon: BookOpen,
    href: "/knowledge",
    iconBg: "bg-green-50",
    iconColor: "text-[#2E7D32]",
    borderColor: "border-l-[#2E7D32]",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FB]">
      <Header />

      {/* Hero Section - 纯白背景，无背景图 */}
      <div className="bg-white">
        <div className="max-w-lg mx-auto px-4 pt-10 pb-8 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <img
              src={LOGO_URL}
              alt="泌外医学中心"
              className="w-24 h-24 mx-auto rounded-full border-3 border-[#1565C0]/20 shadow-lg mb-5"
            />
          </motion.div>
          <motion.h1
            className="text-xl font-bold text-[#1565C0] mb-1 tracking-wide"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            泌尿系感染性结石
          </motion.h1>
          <motion.h2
            className="text-lg font-bold text-[#1565C0] mb-3"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            随访管理循证智能助手
          </motion.h2>
          <motion.div
            className="flex items-center justify-center gap-2 text-gray-500 text-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <span>循证护理</span>
            <span className="w-1 h-1 rounded-full bg-[#F57C00]" />
            <span>专业随访</span>
            <span className="w-1 h-1 rounded-full bg-[#F57C00]" />
            <span>守护健康</span>
          </motion.div>
        </div>
        {/* 浅灰分割线过渡 */}
        <div className="h-[1px] bg-gray-100" />
      </div>

      {/* Feature Cards */}
      <motion.div
        className="max-w-lg mx-auto px-4 pt-5 pb-28 w-full"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="space-y-3">
          {features.map((f) => (
            <motion.div key={f.title} variants={itemVariants}>
              <Link href={f.href}>
                <div className={`bg-white rounded-xl shadow-sm hover:shadow-md transition-all border-l-4 ${f.borderColor} p-4 flex items-center gap-4 active:scale-[0.98]`}>
                  <div className={`w-12 h-12 rounded-xl ${f.iconBg} flex items-center justify-center flex-shrink-0`}>
                    <f.icon className={`w-6 h-6 ${f.iconColor}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 text-base">{f.title}</h3>
                    <p className="text-sm text-gray-500 mt-0.5">{f.desc}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-300 flex-shrink-0" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Hospital Intro Link + Evidence Source */}
        <motion.div
          className="mt-6 text-center space-y-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          {/* 医院简介超链接 */}
          <a
            href="https://mp.weixin.qq.com/s/WjbOAz0pKxAEpc1wZt_Dzg"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-[#1565C0] text-xs font-medium hover:underline transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>广州医科大学附属第一医院泌尿医学中心（泌尿外科）简介</span>
          </a>

          {/* 知识源自证据来源 */}
          <div className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-50 rounded-full">
            <div className="w-1.5 h-1.5 rounded-full bg-[#1976D2]" />
            <span className="text-xs text-[#1565C0] font-medium">
              知识源自《泌尿系感染性结石患者随访管理的最佳证据总结》
            </span>
          </div>
        </motion.div>
      </motion.div>

      <BottomBar />
    </div>
  );
}
