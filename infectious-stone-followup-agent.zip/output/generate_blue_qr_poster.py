from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import qrcode
from qrcode.constants import ERROR_CORRECT_H

TARGET_URL = "https://infstonefa-jr4utuhc.manus.space"
BASE = Path("/home/ubuntu/infectious-stone-followup-agent/output")
BASE.mkdir(parents=True, exist_ok=True)
LOGO_PATH = Path("/home/ubuntu/upload/泌外医学中心.webp")
QR_OUT = BASE / "infectious_stone_blue_qr.png"
POSTER_OUT = BASE / "infectious_stone_blue_qr_poster.png"

BLUE = (38, 113, 216)
DEEP_BLUE = (27, 94, 170)
ORANGE = (241, 157, 43)
TEXT_DARK = (38, 38, 38)
TEXT_MID = (120, 120, 120)
BG = (255, 255, 255)
PANEL = (246, 248, 252)


def load_font(size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates = [
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
            "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ]
    else:
        candidates = [
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def text_size(draw, text, font):
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


def create_qr(url: str):
    qr = qrcode.QRCode(
        version=None,
        error_correction=ERROR_CORRECT_H,
        box_size=16,
        border=3,
    )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color=BLUE, back_color="white").convert("RGBA")
    img = img.resize((1180, 1180), Image.Resampling.NEAREST)

    logo = Image.open(LOGO_PATH).convert("RGBA")
    logo_size = 220
    logo = logo.resize((logo_size, logo_size), Image.Resampling.LANCZOS)

    plate_size = 250
    plate = Image.new("RGBA", (plate_size, plate_size), (255, 255, 255, 0))
    pdraw = ImageDraw.Draw(plate)
    pdraw.ellipse((7, 7, plate_size - 7, plate_size - 7), fill=(255, 255, 255, 255), outline=(220, 228, 240, 255), width=4)
    shadow = Image.new("RGBA", (plate_size + 30, plate_size + 30), (255, 255, 255, 0))
    sdraw = ImageDraw.Draw(shadow)
    sdraw.ellipse((15, 15, plate_size + 15, plate_size + 15), fill=(0, 0, 0, 65))
    shadow = shadow.filter(ImageFilter.GaussianBlur(10))

    composed = Image.new("RGBA", img.size, (255, 255, 255, 255))
    composed.alpha_composite(img)

    center_x = (img.width - plate_size) // 2
    center_y = (img.height - plate_size) // 2
    composed.alpha_composite(shadow, (center_x - 15, center_y - 15))
    composed.alpha_composite(plate, (center_x, center_y))
    logo_x = (img.width - logo_size) // 2
    logo_y = (img.height - logo_size) // 2
    composed.alpha_composite(logo, (logo_x, logo_y))
    return composed


def rounded_rectangle(draw, xy, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def create_poster(qr_img: Image.Image):
    width, height = 1125, 1650
    poster = Image.new("RGB", (width, height), BG)
    draw = ImageDraw.Draw(poster)

    title_font = load_font(38, bold=True)
    subtitle_font = load_font(28, bold=True)
    body_font = load_font(22, bold=False)
    mid_font = load_font(26, bold=True)
    small_font = load_font(19, bold=False)
    small_bold_font = load_font(19, bold=True)

    logo = Image.open(LOGO_PATH).convert("RGBA").resize((164, 164), Image.Resampling.LANCZOS)
    small_logo = Image.open(LOGO_PATH).convert("RGBA").resize((132, 132), Image.Resampling.LANCZOS)

    poster.paste(small_logo, (80, 56), small_logo)

    hospital_1 = "广州医科大学附属第一医院"
    hospital_2 = "泌尿外科"
    w1, h1 = text_size(draw, hospital_1, title_font)
    draw.text(((width - w1) / 2 + 90, 72), hospital_1, font=title_font, fill=DEEP_BLUE)
    w2, h2 = text_size(draw, hospital_2, subtitle_font)
    draw.text(((width - w2) / 2 + 65, 126), hospital_2, font=subtitle_font, fill=DEEP_BLUE)
    line_w = 150
    draw.rounded_rectangle(((width - line_w) / 2 + 70, 186, (width + line_w) / 2 + 70, 192), radius=3, fill=ORANGE)

    main_1 = "泌尿系感染性结石"
    main_2 = "随访管理循证智能助手"
    w3, _ = text_size(draw, main_1, load_font(54, bold=True))
    draw.text(((width - w3) / 2, 250), main_1, font=load_font(54, bold=True), fill=TEXT_DARK)
    w4, _ = text_size(draw, main_2, load_font(54, bold=True))
    draw.text(((width - w4) / 2, 322), main_2, font=load_font(54, bold=True), fill=TEXT_DARK)

    slogan = "循证护理  ·  专业随访  ·  守护健康"
    ws, _ = text_size(draw, slogan, body_font)
    draw.text(((width - ws) / 2, 418), slogan, font=body_font, fill=TEXT_MID)

    panel_x1, panel_y1 = 80, 505
    panel_x2, panel_y2 = width - 80, 1335
    rounded_rectangle(draw, (panel_x1, panel_y1, panel_x2, panel_y2), 28, fill=PANEL)
    rounded_rectangle(draw, (panel_x1 + 24, panel_y1 + 24, panel_x2 - 24, panel_y2 - 24), 10, fill=BG)

    qr_resized = qr_img.convert("RGB").resize((825, 825), Image.Resampling.LANCZOS)
    qr_x = (width - qr_resized.width) // 2
    qr_y = 560
    poster.paste(qr_resized, (qr_x, qr_y))

    info1 = "扫描上方二维码"
    info2 = "即可在手机端访问使用"
    wi1, _ = text_size(draw, info1, mid_font)
    draw.text(((width - wi1) / 2, 1390), info1, font=mid_font, fill=DEEP_BLUE)
    wi2, _ = text_size(draw, info2, body_font)
    draw.text(((width - wi2) / 2, 1435), info2, font=body_font, fill=TEXT_MID)

    dot_y = 1498
    dot_xs = [width // 2 - 30, width // 2, width // 2 + 30]
    dot_colors = [BLUE, ORANGE, BLUE]
    for x, c in zip(dot_xs, dot_colors):
        draw.ellipse((x - 6, dot_y - 6, x + 6, dot_y + 6), fill=c)

    footer = "知识源自《泌尿系感染性结石患者随访管理的最佳证据总结》"
    wf, _ = text_size(draw, footer, small_bold_font)
    draw.text(((width - wf) / 2, 1565), footer, font=small_bold_font, fill=ORANGE)

    return poster


def main():
    qr_img = create_qr(TARGET_URL)
    qr_img.save(QR_OUT)
    poster = create_poster(qr_img)
    poster.save(POSTER_OUT, quality=95)
    print(f"URL={TARGET_URL}")
    print(f"QR={QR_OUT}")
    print(f"POSTER={POSTER_OUT}")


if __name__ == "__main__":
    main()
