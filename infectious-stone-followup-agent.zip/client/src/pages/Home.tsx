/*
 * Design Philosophy: Reference-Matched Clinical Home Screen
 * This page must closely follow the provided screenshot in text, spacing,
 * alignment, white background, and two-card entry layout.
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Activity, BookOpen, ChevronRight, ExternalLink } from "lucide-react";
import Header from "@/components/Header";
import BottomBar from "@/components/BottomBar";

const LOGO_URL = "/manus-storage/guangyi-urology-logo_1693cea2.webp";

const features = [
  {
    title: "随访评估",
    desc: "症状自测 · 指标对比 · 风险分级",
    href: "/assessment",
    icon: Activity,
    iconBg: "bg-blue-50",
    iconColor: "text-[#2F7EDB]",
    accent: "bg-[#2F7EDB]",
  },
  {
    title: "健康知识",
    desc: "饮食干预 · 酸化尿液 · 预防复发",
    href: "/knowledge",
    icon: BookOpen,
    iconBg: "bg-green-50",
    iconColor: "text-[#33A34A]",
    accent: "bg-[#33A34A]",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      <main className="max-w-lg mx-auto w-full bg-white px-0 pb-28">
        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="px-4 pt-10 pb-6 text-center"
        >
          <div className="mx-auto flex h-[116px] w-[116px] items-center justify-center rounded-full bg-white shadow-[0_6px_20px_rgba(27,99,180,0.16)] ring-1 ring-[#DCE8F7]">
            <img src={LOGO_URL} alt="泌外医学中心" className="h-[104px] w-[104px] rounded-full object-contain" />
          </div>

          <h1 className="mt-9 text-[19px] font-bold leading-9 text-[#1D5FAF]">泌尿系感染性结石</h1>
          <h2 className="text-[18px] font-bold leading-9 text-[#1D5FAF]">随访管理循证智能助手</h2>

          <div className="mt-4 flex items-center justify-center gap-2 text-[14px] text-[#7C7C7C]">
            <span>循证护理</span>
            <span className="text-[#F5A623]">•</span>
            <span>专业随访</span>
            <span className="text-[#F5A623]">•</span>
            <span>守护健康</span>
          </div>
        </motion.section>

        <div className="bg-[#FAFAFA] px-4 pt-5 pb-6">
          <div className="space-y-4">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.06 * (index + 1), duration: 0.35 }}
                >
                  <Link href={feature.href}>
                    <div className="relative overflow-hidden rounded-[20px] border border-[#EAEAEA] bg-white shadow-[0_4px_14px_rgba(0,0,0,0.05)] transition-all hover:shadow-[0_6px_18px_rgba(0,0,0,0.07)] active:scale-[0.99]">
                      <div className={`absolute inset-y-0 left-0 w-[4px] ${feature.accent}`} />
                      <div className="flex items-center gap-4 px-5 py-4">
                        <div className={`flex h-14 w-14 items-center justify-center rounded-[18px] ${feature.iconBg} shadow-[0_6px_16px_rgba(47,126,219,0.08)]`}>
                          <Icon className={`h-7 w-7 ${feature.iconColor}`} />
                        </div>
                        <div className="min-w-0 flex-1 text-left">
                          <div className="text-[17px] font-bold text-[#222222]">{feature.title}</div>
                          <div className="mt-1 text-[14px] text-[#8A8A8A]">{feature.desc}</div>
                        </div>
                        <ChevronRight className="h-5 w-5 flex-shrink-0 text-[#D1D1D1]" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          <div className="pt-5 text-center">
            <a
              href="https://mp.weixin.qq.com/s/WjbOAz0pKxAEpc1wZt_Dzg"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[14px] font-semibold text-[#2A6DB7] hover:underline"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span>广州医科大学附属第一医院泌尿医学中心（泌尿外科）简介</span>
            </a>

            <div className="mx-auto mt-4 inline-flex max-w-full items-center gap-1.5 rounded-full bg-[#F5FAFF] px-4 py-2 text-[13px] text-[#2A6DB7] shadow-[0_2px_10px_rgba(47,126,219,0.06)]">
              <span className="text-[#2F7EDB]">•</span>
              <span>知识源自《泌尿系感染性结石患者随访管理的最佳证据总结》</span>
            </div>
          </div>
        </div>
      </main>

      <BottomBar />
    </div>
  );
}
