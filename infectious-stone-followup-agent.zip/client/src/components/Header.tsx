/*
 * Design Philosophy: Reference-Matched Clinical Home Screen
 * Header must follow the provided screenshot with left-aligned logo,
 * two-line institution text, and a clean white medical bar.
 */
import { Link, useLocation } from "wouter";
import { ArrowLeft, Home } from "lucide-react";

const LOGO_URL = "/manus-storage/guangyi-urology-logo_1693cea2.webp";

export default function Header() {
  const [location] = useLocation();
  const isHome = location === "/";

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#EDEDED]">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
        {!isHome ? (
          <Link href="/">
            <button className="flex h-8 w-8 items-center justify-center rounded-full bg-[#F5F5F5] hover:bg-[#ECECEC] transition-colors">
              <ArrowLeft className="w-4.5 h-4.5 text-[#2B6CB0]" />
            </button>
          </Link>
        ) : null}

        <img
          src={LOGO_URL}
          alt="泌外医学中心"
          className="h-9 w-9 rounded-full object-contain flex-shrink-0"
        />

        <div className="min-w-0 flex-1 leading-tight">
          <p className="truncate text-[12px] text-[#7A7A7A]">广州医科大学附属第一医院</p>
          <p className="truncate mt-1 text-[14px] font-bold text-[#1D5FAF]">泌尿外科</p>
        </div>

        {!isHome ? (
          <Link href="/">
            <button className="flex h-8 w-8 items-center justify-center rounded-full bg-[#F5F5F5] hover:bg-[#ECECEC] transition-colors">
              <Home className="w-4.5 h-4.5 text-[#2B6CB0]" />
            </button>
          </Link>
        ) : null}
      </div>
    </header>
  );
}
