/*
 * Design Philosophy: Reference-Matched Clinical Home Screen
 * Bottom bar must follow the provided screenshot with an orange rounded
 * action button labeled '随访登记系统'.
 */
import { Link } from "wouter";
import { ClipboardList } from "lucide-react";

export default function BottomBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 bg-white border-t border-[#EDEDED] shadow-[0_-2px_10px_rgba(0,0,0,0.04)]">
      <div className="max-w-lg mx-auto px-4 py-3">
        <Link href="/registration">
          <button className="w-full flex items-center justify-center gap-2 rounded-[18px] bg-gradient-to-r from-[#FF9D08] to-[#FF9300] px-4 py-4 text-[16px] font-bold text-white shadow-[0_6px_16px_rgba(255,153,0,0.28)] transition-all hover:brightness-105 active:scale-[0.99]">
            <ClipboardList className="w-5 h-5" />
            <span>随访登记系统</span>
          </button>
        </Link>
      </div>
    </div>
  );
}
